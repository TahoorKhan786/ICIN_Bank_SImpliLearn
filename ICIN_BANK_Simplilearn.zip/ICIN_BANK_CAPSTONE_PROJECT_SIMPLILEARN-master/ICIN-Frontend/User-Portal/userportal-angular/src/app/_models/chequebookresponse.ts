export class ChequebookResponse{
    status:boolean;
    responseMessage:String;
    account:number;
}